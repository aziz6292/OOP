#pragma once
#include <iostream>
using namespace std;
class Matrix
{
	int** matrix;
	int row, col;
public:

	Matrix(int = 0, int = 0);
	Matrix(const Matrix&);
	void setMatrix(int, int);
	void input();
	int** getMatrix()const;
	void setVal(int, int, int);
	const int getNoRow()const;
	const int getNoCol()const;
	void display()const;
	Matrix& operator = (const Matrix&);
	Matrix operator+ (const Matrix&);
	Matrix operator * (const Matrix&);
	bool  operator> (const Matrix&);
	bool operator == (const Matrix&);
	Matrix operator *(int);
	operator int();
	operator int*();
	~Matrix();
};

