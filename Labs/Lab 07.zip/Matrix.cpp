#include "Matrix.h"
Matrix::Matrix( int r, int c)
{
	cout << "Perametrize Constructor Call on " << this << endl;
	setMatrix(r, c);
	

}
Matrix::Matrix(const Matrix& obj)
{
	cout << "Copy Constructor Call on " << this << endl;
	row = obj.row;
	col = obj.col;
	matrix = new int*[row];
	for (int i = 0; i < row; i++)
	{
		matrix[i] = new int[col];
		for (int j = 0; j < col; j++)
		{
			matrix[i][j] = obj.matrix[i][j];
		}
	}
}
void Matrix::setVal(int a, int b, int val)
{
	matrix[a][b] = val;
}
void Matrix::setMatrix( int r, int c)
{
	if (matrix != NULL)
	{
		for (int i = 0; i < row; i++)
		{
			if (matrix[i] != NULL)
			{
				delete[]matrix[i];
				matrix[i] = NULL;
			}
		}
		delete[] matrix;
		matrix = NULL;
	}

	if (r > 0 && c> 0)
	{
		row = r;
		col = c;
		matrix = new int* [row];
		
		for (int i = 0; i < row; i++)
		{
			matrix[i] = new int[col];
			for (int j = 0; j < col; j++)
				matrix[i][j] = 0;
		}
	}
}

void Matrix::input()
{
	for (int i = 0; i < row; i++)
	{
		cout << "Enter row " << i + 1 << ": ";
		for (int j = 0; j < col; j++)
			cin >> matrix[i][j];
	}
}
int** Matrix::getMatrix()const
{
	return matrix;
}
const int Matrix::getNoRow()const
{
	return row;
}
const int Matrix::getNoCol()const
{
	return col;
}
void Matrix::display()const
{
	for (int i = 0; i < row; i++)
	{
		for (int j = 0; j < col; j++)
		{
			cout << matrix[i][j] << " ";
		}
		cout << endl;
	}
}
Matrix&  Matrix :: operator = (const Matrix& obj)
{
	if (this != &obj)
	{
		if (matrix != NULL)
		{
			for (int i = 0; i < row; i++)
			{
				delete[] matrix[i];
				matrix[i] = NULL;
			}
			delete[] matrix;
			matrix = NULL;
		}
		row = obj.row;
		col = obj.col;
		matrix = new int* [row];
		for (int i = 0; i < row; i++)
		{
			matrix[i] = new int[col];
			for (int j = 0; j < col; j++)
			{
				matrix[i][j] = obj.matrix[i][j];
			}
		}
		return *this;
	}
}
Matrix Matrix::operator+ (const Matrix& obj)
{
	
	if (row != obj.row)
	{
		Matrix invalid(0, 0);
		cout << "Order is not same so Sum is not Possible\n";
		return invalid;
		if (col != obj.col)
		{
			cout << "Order is not same so Sum is not Possible\n";
			return invalid;
		}
	}
	
	Matrix temp(row, col);
	int val = 0;
	for (int i = 0; i < row; i++)
	{
		for (int j = 0; j < col; j++)
		{
			val = matrix[i][j] + obj.matrix[i][j];
			temp.setVal(i, j, val);
		}
	}
	return temp;
}
Matrix Matrix:: operator * (const Matrix& obj)
{
	
	if (col != obj.row)
	{
		Matrix invalid(0, 0);
		cout << "Multiplication is not Possible\n";
		return invalid;
	}
	
	
	Matrix temp( row, obj.col);
	//temp.display();
	int val = 0;
	for (int i = 0; i < row; i++)
	{
		for (int j = 0; j < obj.col; j++)
		{
			val = 0;
			for (int k = 0; k < row; k++)
			{
				val = val + matrix[i][k] * obj.matrix[k][j];
			}
			//temp.matrix[i][j] = val;
			temp.setVal(i,j,val);
		}

	}
	return temp;
}
bool  Matrix::operator> (const Matrix& obj)
{

	if (row != obj.row)
	{
		return false;
	}
	if (col != obj.col)
	{

		return false;
	}
	for (int i = 0; i < row; i++)
	{
		for (int j = 0; j < col; j++)
		{
			if (!(matrix[i][j] > obj.matrix[i][j]))
				return false;
		}
	}
	return true;
}
bool Matrix::operator == (const Matrix& obj)
{
	if (row != obj.row)
	{

		return false;
	}
	if (col != obj.col)
	{

		return false;
	}
	for (int i = 0; i < row; i++)
	{
		for (int j = 0; j < col; j++)
		{
			if (matrix[i][j] != obj.matrix[i][j])
				return false;
		}
	}
	return true;
}
Matrix Matrix::operator *(int val)
{
	
	Matrix temp(row, col);
	for (int i = 0; i < row; i++)
	{
		for (int j = 0; j < col; j++)
		{
			temp.setVal(i, j, matrix[i][j] * val);
		}
	}
	return temp;
}
Matrix::operator int()
{
	int sum =0;
	for (int i = 0; i < row; i++)
	{
		for (int j = 0; j < col; j++)
		{
			sum += matrix[i][j];
		}
	}
	return sum;
}
Matrix ::  operator int* ()
{
	int* ptr = new int [row];
	for (int i = 0; i < row; i++)
	{
		ptr[i] = 1;
		for (int j = 0; j < col; j++)
		{
			ptr[i] *= matrix[i][j];
		}
	}
	return ptr;
}
Matrix:: ~Matrix()
{
	for (int i = 0; i < row; i++)
	{
		if (matrix[i] != NULL)
		{
			delete[]matrix[i];
			matrix[i] = NULL;
		}
	}
	if (matrix != NULL)
	{
		delete[] matrix;
		matrix = NULL;
	}
}
