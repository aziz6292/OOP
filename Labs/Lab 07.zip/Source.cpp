#include "Matrix.h"

int main()
{
	int row, col;
	cout << "Enter row & col for the Matrix: ";
	cin >> row >> col;
	Matrix A(row, col);//Creating Matrix with Perametrize Constructor
	A.input(); //Taking Input from the user
	A.display(); //Displaying
	Matrix C = A; // Creating C through Copy Constructor by A
	if (A == C) // == operator Test
	{
		cout << "Equal\n";
	}
	else
	{
		cout << "Not Equal\n";
	}
	if (A > C) // > operator test
	{
		cout << "Greater\n";
	}
	else
	{
		cout << "Not Greater\n";
	}
	Matrix D = C + A; // Matrix + Matrix operator test
	D.display();
	int sum = D; // operator int test
	cout << sum << endl;
	int* ptr = D;// operator int* test
	for (int i = 0; i < D.getNoRow(); i++)
		cout << ptr[i] << endl;
	D = C * 2; //operator Matrix * scalar test 
	D.display(); 
	D = C * A; // operator Matrix * Matrix test
	D.display();
	D = C = A; //Cascading operator = test
	D.display();
	return 0;
}