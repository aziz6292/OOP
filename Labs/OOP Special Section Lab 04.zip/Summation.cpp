#include "Summation.h"
Summation ::Summation() : a(0), b(0), c(1), p(1), ans(0)
{
}
void Summation::setData(char i)
{
    while (i < '1' || i > '3')
    {
        cout << "Invalid\nRe-enter type 1-3: ";
        cin >> i;
    }
    type = i;
    cout << "Enter range: ";
    cin >> a >> b;
    while (a > b)
    {
        cout << "Invalid\nRe-enter: ";
        cin >> a >> b;
    }
    if (i == '2')
    {
        cout << "Enter Coefficient: ";
        cin >> c;
        while (c == 0)
        {
            cout << "Invalid\nRe-enter: ";
            cin >> c;
        }
    }
    else if (i == '3')
    {
        cout << "Enter Power: ";
        cin >> p;
    }
}
int Summation::getResult()
{
    ans = 0;
    int i = a - 1;
    if (type == '1')
        while (++i <= b)
            ans += i;
    else if (type == '2')
        while (++i <= b)
            ans += i * c;
    else
        while (++i <= b)
            ans += pow(i, p);
    return ans;
}
Summation &Summation ::operator++()
{
    ++b;
    return *this;
}
Summation Summation ::operator+(int val)
{
    Summation temp =*this;
    temp.b += val;
    return temp;
}