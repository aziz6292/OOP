#ifndef SUMMATION_H
#define SUMMATION_H
#include <iostream>
#include <cmath>
using namespace std;
class Summation
{
private:
    int a, b, c, p;
    char type;
    int ans;
public:
    Summation();
    void setData(char);
    int getResult();
    Summation &operator++();
    Summation operator+(int);
};
#endif