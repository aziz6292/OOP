#include "Summation.cpp"
int main()
{
    Summation A;
    cout << "Enter Type of Summation: ";
    char ch;
    cin >> ch;
    while (ch < '1' || ch > '3')
    {
        cout << "Invalid\nRe-enter: ";
        cin >> ch;
    }
    A.setData(ch);
    cout << "Result " << A.getResult() << endl;
    ++A;
    cout << "Operator++ " << A.getResult() << endl;
    A = A + 1;
    cout << "Operator + " << A.getResult() << endl;
    return 0;
}