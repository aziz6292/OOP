#include "TransformationMatrix.h"

int main()
{
	cout << fixed << showpoint << setprecision(2);// just for farmitting
	//The below 2 line will fast your IDE to run
	cin.sync_with_stdio(0);
	cin.tie(0);
	TransformationMatrix image;
	Point pexil;//any point befor the transformation
	char choice;
	//getting Value from the user
	cout << "\tGetting Value From the User\n";
	float val;// any temp var to set value in different attributes
	cout << "Enter the X-coordinate of the Point: ";
	cin >> val;
	pexil.setX(val);// set point (pexil) x-coOrdinate
	cout << "Enter the Y-coodinate of the Point: ";
	cin >> val;
	pexil.setY(val);// set point (pexil) y-coordinate
	//Set p present in the Transformation class for object image
	image.setP(pexil);

	//Getting value from user for different transformation thechniques
	//1 -> Scaling
	cout << "Enter the Sx to Scale at: ";
	cin >> val;
	image.setSx(val);
	cout << "Enter the Sy to Scale at: ";
	cin >> val;
	image.setSy(val);
	//2 -> Rotation
	cout << "Enter the Angle (theta) in Degree to rotate at: ";
	cin >> val;
	image.setTheta(val);
	//3 -> Shear
	cout << "Enter the shx to Shear at: ";
	cin >> val;
	image.setShx(val);
	cout << "Enter the shy to shear at: ";
	cin >> val;
	image.setShy(val);
	while (1)
	{
		cout << "Select the type of transformation from the following\n";
		cout << "Press '1' for Scaling\n";
		cout << "Press '2' for Rotation\n";
		cout << "Press '3' for Shear\n";
		cout << "Press '4' to exit\n";
		cout << "Your Selection: ";
		cin >> choice;
		while (choice < '1' || choice > '4')
		{
			cout << "Invalid Selection\n";
			cout << "Please Select in range of 1-4: ";
			cin >> choice;
		}
		if (choice == '4')
			exit(0);
		cout << "\n\tOUTPUTING\n";
		image.transform(choice);
		cout << endl << endl << endl;
		cout << "Press Enter to continue........";
		system("pause>0");
		system("cls");
	}

	return 0;
}