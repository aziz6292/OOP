#include "TransformationMatrix.h"
const int row = 2, col = 2;
TransformationMatrix::TransformationMatrix(float a, float b, float t, float d, float e, Point f)
{
	setSx(a);
	setSy(b);
	setTheta(t);
	setShx(d);
	setShy(e);
	setP(f);
	setMatrix();
}
TransformationMatrix::TransformationMatrix(const TransformationMatrix& obj) : p(obj.p)
{
	setSx(obj.getSx());
	setSy(obj.getSy());
	setTheta(obj.getTheta());
	setShx(obj.getShx());
	setShy(obj.getShy());
	setMatrix();

}
void TransformationMatrix :: setMatrix()
{
	
	matrix = new float* [row];
	for (int i = 0; i < row; i++)
	{
		matrix[i] = new float[col];
	}
	for (int i = 0; i < row; i++)
	{
		for (int j = 0; j < col; j++)
		{
			matrix[i][j] = 0;
		}
	}
}

void TransformationMatrix::transform(const char sel)
{
	
	Point transformPoint;
	if (sel == '1')
	{
		//Scalling
		//value assigning
		matrix[0][0] = Sx;
		matrix[1][1] = Sy;
		//Multiplicataion
		transformPoint.setX(matrix[0][0] * p.getX() + matrix[0][1] * p.getY());
		transformPoint.setY(matrix[1][0] * p.getX() + matrix[1][1] * p.getY());
		cout << "Before the Scaling the Original Point (x,y): ";
		p.display();
		//to display the new transformed point;
		cout << "\nAfter the Scaling the Point become (x', y'): ";
		transformPoint.display();
	}
	else if (sel == '2')
	{
		//Rotation
		//Assigning value to each index
		matrix[0][0] = cos(theta);
		matrix[0][1] = -(sin(theta));
		matrix[1][0] = sin(theta);
		matrix[1][1] = cos(theta);
		//Multiplication
		transformPoint.setX(matrix[0][0] * p.getX() + matrix[0][1] * p.getY());
		transformPoint.setY(matrix[1][0] * p.getX() + matrix[1][1] * p.getY());
		cout << "Before the Rotation the Original Point (x,y): ";
		p.display();
		//to display the new transformed point;
		cout << "\nAfter the Rotation the Point become (x', y'): ";
		transformPoint.display();
	}
	else
	{
		//Shear
		matrix[0][0] = 1;
		matrix[0][1] = shx;
		matrix[1][0] = shy;
		matrix[1][1] = 1;
		transformPoint.setX(matrix[0][0] * p.getX() + matrix[0][1] * p.getY());
		transformPoint.setY(matrix[1][0] * p.getX() + matrix[1][1] * p.getY());
		cout << "Before the Shear the Original Point (x,y): ";
		p.display();
		//to display the new transformed point;
		cout << "\nAfter the Shear the Point become (x', y'): ";
		transformPoint.display();
	}
	
}
void TransformationMatrix::setSx(float a)
{
	Sx = a;
}
void TransformationMatrix::setSy(float a)
{
	Sy = a;
}
void TransformationMatrix::setTheta(float a)
{
	theta = a;
}
void TransformationMatrix::setShx(float a)
{
	shx = a;
}
void TransformationMatrix::setShy(float a)
{
	shy = a;
}
void TransformationMatrix::setP(Point a)
{
	p = a;
}
const float TransformationMatrix::getSx()const
{
	return Sx;
}
const float TransformationMatrix::getSy()const
{
	return Sy;
}
const float TransformationMatrix::getTheta()const
{
	return theta;
}
const float TransformationMatrix::getShx()const
{
	return shx;
}
const float TransformationMatrix::getShy()const
{
	return shy;
}
const Point TransformationMatrix::getP()const
{
	return p;
}

TransformationMatrix ::~TransformationMatrix()
{
	if (matrix != NULL)
	{
		//Deleting Dynomically creating Matrix
		for (int i = 0; i < row; i++)
		{
			//Deleting the each row pointer of the 2D matrix one by one
			if (matrix[i] != NULL)
			{
				delete[] matrix[i];
				matrix[i] = NULL;
			}
		}
		//Now to delete the pointer Array containing addresses of each rows
		delete[] matrix;
		matrix = NULL;
	}
}