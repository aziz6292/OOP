#pragma once
#include <iostream>
#include <iomanip>
#include <cmath>
using namespace std;
class Point
{
	float x;
	float y;
public:
	Point(float = 0, float = 0);
	void setX(float);
	void setY(float);
	const float getX()const;
	const float getY()const;
	void display()const;
};
