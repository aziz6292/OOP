#pragma once
#include "Point.h"
class TransformationMatrix
{
	float Sx, Sy, theta, shx, shy;
	float** matrix;
	Point p;
public:
	TransformationMatrix(float = 0, float = 0, float = 0, float = 0, float = 0, Point = { 0,0 });
	TransformationMatrix(const TransformationMatrix&);
	void setSx(float);
	void setSy(float);
	void setTheta(float);
	void setShx(float);
	void setShy(float);
	void setMatrix();
	void setP(Point);
	const float getSx()const;
	const float getSy()const;
	const float getTheta()const;
	const float getShx()const;
	const float getShy()const;
	void transform(const char);
	const Point getP()const;
	~TransformationMatrix();
};

