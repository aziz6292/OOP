#include "Point.h"
Point::Point(float a, float b)
{
	setX(a);
	setY(b);
}
void Point::setX(float a)
{
	x = a;
}
void Point::setY(float b)
{
	y = b;
}
const float Point::getX()const
{
	return x;
}
const float Point::getY()const
{
	return y;
}
void Point::display()const
{
	cout << "(" << getX() << "," << getY() << ")" << endl;// (a,b)
}