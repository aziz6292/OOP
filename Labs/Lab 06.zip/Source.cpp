#include <iostream>
#include <string> // include for some string builtin fun like string.size(), getline etc
using namespace std;
int main() {
	//Inputting Data for 2 String to find LD-Distance
	string word1 = "\0", word2 = "\0"; // declaring 2 stirng with initilizing with Null terminator
	cout << "\tPlease Enter 2 Words to find LD-Distance\n";
	cout << "1st Word: ";
	getline(cin, word1);// getting 1st String from the user 
	cout << "2nd Word: ";
	getline(cin, word2);// getting 2nd Stirng from the user
	// Now to Creat a 2D Matrix Dynomically according to no of char of word1 and word2
	int** LDMatrix, min = 0; // Declaring a 2D pointer name LDMatrix and an int varriable called min
	LDMatrix = new int* [word1.size() + 1];// allocating int pointer arrays of size = length of stirng 1
	for (int i = 0; i < word1.size() + 1; i++) { // this loop will iterate until no of char of string 1 (word1)
		LDMatrix[i] = new int[word2.size() + 1]; // this is for allocating memory for each pointer of the pointer array that we allocate in line just above the loop
		if (i == 0) {
			cout << "\nLD_Matrix\n  # ";
			for (int k = 0; k < word2.size(); k++)
				cout << word2[k] << " ";
			cout << "\n# ";
		}
		for (int j = 0; j < word2.size() + 1; j++) { // this loop will go until no of char of string 2 (word2)
			if (j == 0 || i == 0) { // checking for 1st row and 1st col
				if (i == 0) // if 1st row assiging j( 0 to (no of char of word2)) to each element of 1st row
					LDMatrix[i][j] = j;
				else { // it mean 1st col but not 1st row so assigning i ( 1 to (no of char of word1)) to each 1st element of each rows
					LDMatrix[i][j] = i;
					cout << word1[i - 1] << " ";
				}
			}
			else { //checking for element rather than 1st row and 1st col
				if (word1[i - 1] == word2[j - 1]) { // checking for( ith char of word1 is equal to jth char of word2)
					LDMatrix[i][j] = LDMatrix[i - 1][j - 1]; // assinging the previous max to the current ith , jth element
				}
				else {// if not same (equal)
					min = LDMatrix[i - 1][j - 1]; //above Diagnonal element (previous row previous col)// Now to find the min between above/ above diagnol/ and left one
					if (min > LDMatrix[i - 1][j]) //above element of the Previous row in the same col 2D matrix
						min = LDMatrix[i - 1][j];
					if (min > LDMatrix[i][j - 1])//Left element in the same row
						min = LDMatrix[i][j - 1];
					LDMatrix[i][j] = min + 1;
				}
			}
			cout << LDMatrix[i][j] << " "; // Displaying the Matrix element one by one
		}cout << endl;
	}cout << endl << "LD_Distance Between (" << word1 << " && " << word2 << ") is \"Lower Right Corner element\" of the Matrix which is = " << LDMatrix[word1.size()][word2.size()] << endl << endl;
	for (int i = 0; i < word1.size() + 1; i++) {//Deallocating the 2D matrix
		delete[] LDMatrix[i];// Deleting the (element arrays) ith pointer (row) 
		LDMatrix[i] = NULL;
	} delete[] LDMatrix;// Deleting the (pointer array) containg the addresses
	LDMatrix = NULL;
	return 0;
}