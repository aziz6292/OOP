#include "Image.h"
void displayM(int**, int**);
Image::Image()
{
	image = new int* [6];
	convolutedMatrix = new int* [6];
	nighberPixels = new int* [3];
	for (int i = 0; i < 6; i++)
	{
		if (i < 3)
		{
			nighberPixels[i] = new  int[3];
		}
		image[i] = new int[6];
		convolutedMatrix[i] = new int[6];
	}
	for (int i = 0; i < 3; i++)
		for (int j = 0; j < 3; j++)
		{
			nighberPixels[i][j] = 1;
		}
	cout << "\n\tSet the Image Matrix!\n";
	for (int i = 0; i < 6; i++)
	{
		cout << "row" << i + 1 << ": ";
		for (int j = 0; j < 6; j++)
		{
			cin >> image[i][j];
			convolutedMatrix[i][j] = 0;
		}
	}
}

void Image::check(int** image, int** nighberPixels, int px, int py, int m, int n)
{
	if ((px - 1) > -1)
	{
		if ((py - 1) > -1)
		{
			if ((px - 1) < 6)
			{
				if ((py - 1) < 6)
				{
					nighberPixels[m][n] = image[px - 1][py - 1];
				}
				else
				{
					nighberPixels[m][n] = 1;
				}
			}
			else
			{
				nighberPixels[m][n] = 1;
			}
		}
		else
		{
			nighberPixels[m][n] = 1;
		}
	}
	else
	{
		nighberPixels[m][n] = 1;
	}
}
void Image::convolution()
{
	int px = 0, py = 0;
	for (int i = 0; i < 6; i++)
	{
		py = 0;
		px = i;
		for (int j = 0; j < 6; j++)
		{
			py = j;
			px = i;
			for (int m = 0; m < 3; m++)
			{
				for (int n = 0; n < 3; n++)
				{

					check(image, nighberPixels, px, py, m, n);
					py++;
					//cout << image[n][m] << " ";
				}
				px++;
				py = j;
				cout << endl;
			}
			displayM(nighberPixels, image);
			cout << endl;
		    cout << setw(28) << ""<< "X\n\n";
			mask.display();
			convolutedMatrix[i][j] = mask.getVal(nighberPixels);
			cout << setw(26) << "";
			cout << "at index A(" << i << j << ") = " << convolutedMatrix[i][j] << endl;
			system("pause>0");
			cout << "\nPress any key to continue the next step...\n";
		}
	}


}


void Image::display()
{
	cout << "\n\tConvoluted Matrix\n\n";
	for (int i = 0; i < 6; i++)
	{
		cout << "\t";
		for (int j = 0; j < 6; j++)
		{

			cout <<setw(4)<< convolutedMatrix[i][j] << " ";

		}
		cout << endl;
	}

}
Image::~Image()
{
	for (int i = 0; i < 6; i++)
	{
		if (i < 3)
		{
			if (nighberPixels[i] != NULL)
			{
				delete[] nighberPixels[i];
				nighberPixels[i] = NULL;
			}
		}
		if (image[i] != NULL)
		{
			delete[] image[i];
			image[i] = NULL;
		}
		if (convolutedMatrix[i] != NULL)
		{
			delete[] convolutedMatrix[i];
			convolutedMatrix[i] = NULL;
		}
	}
	if (nighberPixels != NULL)
	{
		delete[] nighberPixels;
		nighberPixels = NULL;
	}
	if (image != NULL)
	{
		delete[] image;
		image = NULL;
	}
	if (convolutedMatrix != NULL)
	{
		delete[] convolutedMatrix;
		convolutedMatrix = NULL;
	}

}
void displayM(int** matrix, int** image)
{
	cout << setw(20) << "Image  -->" <<setw(20)<< "NighberMatrix\n\n";
	for (int i = 0; i < 6; i++)
	{
		for (int k = 0; k < 6; k++)
			cout <<setw(2)<< image[i][k] << " ";
		cout << setw(5) << "";
		if (i > 1 && i < 5)
			for (int j = 0; j < 3; j++)
				cout << setw(2) << matrix[i - 2][j] << " ";
		cout << endl;
	}

}