#include "Image.h"

int main()
{

	srand(time(0));
	
	while (1)
	{
		cout << "Press any key to continue....";
		cout << "\npress 'Q' to quit: ";
		char a;
		cin>> a;
		if (toupper(a) == 'Q')
			exit(0);
		system("cls");
	}
	return 0;
}
