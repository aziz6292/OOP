#pragma once
#include <iostream>
#include <cstdlib>
#include <stdio.h>
#include <iomanip>
#include <ctime>
using namespace std;
class Mask
{
	int** mask;
public:
	Mask();
	void setMask();
	const Mask getMask()const;
	const int getVal(int**);
	void display()const;
	~Mask();

};

