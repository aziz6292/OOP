#include "Mask.h"
Mask::Mask()
{
	setMask();
}
void Mask:: setMask()
{
	mask = new int* [3];
	for (int i = 0; i < 3; i++)
	{
		mask[i] = new int[3];
	}
	int val = rand() % 9 + 1;
	//cout << "Set any Value for Mask Matrix all index: ";
	//cin >> val;
	for (int i = 0; i < 3; i++)
		for (int j = 0; j < 3; j++)
			mask[i][j] = val;
}
const int Mask::getVal(int** nighberPixels)
{
	int s = 0;
	for (int i = 0; i < 3; i++)
	{
		for (int j = 0; j < 3; j++)
		{
			s += (nighberPixels[i][j] * mask[i][j]);
		}
	}
	return s;
}
const Mask Mask:: getMask()const
{
	return *this;
}
void Mask:: display()const
{
	cout << setw(30)<<"Mask\n\n";
	for (int i = 0; i < 3; i++)
	{
		cout << setw(24) << "";
		for (int j = 0; j < 3; j++)
			cout<< mask[i][j] << " ";
		cout << endl;
	}
}
Mask:: ~Mask()
{
	for (int i = 0; i < 3; i++)
	{
		if (mask[i] != NULL)
		{
			delete[] mask[i];
			mask[i] = NULL;
		}
	}
	delete mask;
	mask = NULL;
}