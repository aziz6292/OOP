#pragma once
#include"Mask.h"
class Image
{
	int** image;
	int** convolutedMatrix;
	int** nighberPixels;
	Mask mask;
public:
	Image();
	void check(int**, int**, int, int, int, int);
	void convolution();
	void display();
	~Image();
};

