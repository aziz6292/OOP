#include <iostream>
#include <sstream>
#include <string>
#include <cctype>
#include <cmath>
#include <fstream>

using namespace std;

class Book 
{
private:
	string name, publisher, auther;
	int  price;
public: 
	Book()
	{
		
		name = " ";
		publisher = " ";
		auther = " ";
		price = 0;
	}
	void getData(string n1 , string n2, string n3, int n)
	{
		name = n1;
		publisher = n2;
		auther = n3;
		price = n;
	}
	void showData()

	{
		cout << "Price of " << name << " is " << price << endl;
		cout << "Auther name: " << auther << endl;
		cout << "Publisher name: " << publisher << endl << endl;
	}
	Book operator + (Book const& obj)
	{
		Book res;
		res.price = price + obj.price;
		return res;
	}
	string compare(Book b1, Book b2)
	{
		if (b1.price > b2.price)
		{
			return b1.name;
		}
		else
		{
			return b2.name;
		}
	}
	void print()
	{
		cout << price;
	}
};




int main()
{
	char repeat;
	do
	{
		Book book1, book2;
		string a1,a2,b1,b2,c1,c2;
		int p1, p2;
		cout << "Enter Name of the book: ";
		getline(cin, a1);
		cout << "Enter Publisher of the book: ";
		getline(cin, b1);
		cout << "Enter Auther name: ";
		getline(cin, c1);
		cout << "Enter price of the book: ";
		cin >> p1;
		cin.ignore();
		cout << "Enter Name of the book: ";
		getline(cin, a2);
		cout << "Enter Publisher of the book: ";
		getline(cin, b2);
		cout << "Enter Auther name: ";
		getline(cin, c2);
		cout << "Enter price of the book: ";
		cin >> p2;
		book1.getData(a1, b1, c1, p1);
		book2.getData(a2, b2, c2, p2);
		book1.showData();
		book2.showData();
		Book book3;
		book3 = book1 + book2;
		cout << "Total price of both books is= ";
		book3.print();
		cout << endl;
		cout<<book3.compare(book1, book2)<<" is more costly\n";
	

		cout << "\n\nDo You want to use again for another input? (A/Q):";
		cin >> repeat;
		while (toupper(repeat) != 'A' && toupper(repeat) != 'Q')
		{
			cout << "ERROR!! invalid input\n";
			cout << "Please Enter A or Q: ";
			cin >> repeat;
		}
	} while (toupper(repeat) != 'Q');

	return 0;
}
