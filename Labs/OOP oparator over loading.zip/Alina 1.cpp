#include <iostream>
#include <cmath>


using namespace std;

class Tringle 
{
private:
	double a, b, c;
public: 
	Tringle()
	{
		a = 0;
		b = 0; 
		c = 0;
	}
	Tringle(double n1, double n2, double n3)
	{
		a = n1;
		b = n2;
		c = n3;
	}
	double setSum()
	{
		return (a + b + c)/2;
	}
	const double area(double n)
	{
		a = n;
		return a * a *(sqrt(3) / 4) ;
	}
	const double area(double n, double n1)
	{
		a = n;
		b = n1;
		return a * b * 0.5;
	}
	const double area(double n, double n1, double n2)
	{
		a = n;
		b = n1;
		c = n2;
		double s = setSum();
		return  sqrt(s * (s - a) * (s - b) * (s - c));
	}

};




int main()
{
	char repeat;
	do
	{
		Tringle t1;
		double a, b, c;
		char choice;
		cout << "Press 1, 2 or 3 To find the area of the following Tringle!\n\n";
		cout << "1. for Right Tringle\n";
		cout << "2. for Equeletral Tringle\n";
		cout << "3. for Scalene Tringle\n";
		cout << "Your Selection: ";
		cin >> choice;
		while (choice < '1' || choice >'3')
		{
			cout << "ERROR!! Invalid input!\n";
			cout << "Please press 1, 2 or 3: ";
			cin >> choice;
		}
		if (choice == '1')
		{
			cout << "Enter base and hight of Right Tringle: ";
			cin >> a >> b;
			cout << "Area of Right angle Tringle is: " << t1.area(a, b) << endl;
		}
		else if (choice == '2')
		{
			cout << "Enter the length of any one side of an equeletral Tringle: ";
			cin >> a;
			cout << "Area of Tringle is: " << t1.area(a) << endl;
		}
		else
		{
			cout << "Enter the Three sides of the scalene Tringle: ";
			cin >> a >> b >> c;
			cout << "Area of Tringle is: " << t1.area(a, b, c) << endl;
		}
		cout << "\n\nDo You want to use again for another input? (A/Q):";
		cin >> repeat;
		while (toupper(repeat) != 'A' && toupper(repeat) != 'Q')
		{
			cout << "ERROR!! invalid input\n";
			cout << "Please Enter A or Q: ";
			cin >> repeat;
		}
	} while (toupper(repeat) != 'Q');

	return 0;
}
