#include <iostream>
#include <iomanip>
using namespace std;

int** createPascalTriangle(int);
void displayPascalTriangle(int**, int);
void deallocatePascalTriangle(int**&, int);

int main()
{
	int row;
	cout << "Enter the no of rows for Pascal Triangle: ";
	cin >> row;
	while (row < 1)
	{
		cout << "ERROR! Invalid input\n";
		cout << "Re-enter the no of rows: ";
		cin >> row;
	}
	int** triangle = createPascalTriangle(row);
	displayPascalTriangle(triangle, row);
	deallocatePascalTriangle(triangle, row);
	if (triangle != nullptr)
		cout << "\nNot deallocted\n";
	else 
		cout <<"\nSuccessfully Deallocated\n";
	return 0;
}
int** createPascalTriangle(int n)
{
	int** arr = new int* [n];
	for (int i = 0; i < n; i++)
	{
		arr[i] = new int[i + 1];
	}
	for (int i = 0; i < n; i++)
	{
		for (int j = 0; j <= i; j++)
		{
			if (j == 0)
				arr[i][j] = 1;
			else if (j == i)
				arr[i][j] = 1;
			else
				arr[i][j] = arr[i - 1][j - 1] + arr[i - 1][j];

		}
	}
	return arr;
}
void displayPascalTriangle(int** arr, int n)
{
	cout << "\n\nPascal Triangle\n\n";
	for (int i = 0; i < n; i++)
	{
		for (int j = 0; j <= i; j++)
		{
			cout << arr[i][j] << " ";
		}
		cout << endl;
	}
	
}
void deallocatePascalTriangle(int**& arr, int n)
{
	for (int i = 0; i < n; i++)
	{
		delete[]arr[i];
		arr[i] = nullptr;
	}
	delete[]arr;
	arr = nullptr;
}