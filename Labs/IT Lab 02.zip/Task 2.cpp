#include <iostream>
#include <iomanip>
using namespace std;

struct Purchase
{
	int invoice;
	double amount;
	double tax;
};


int main()
{
	Purchase obj = { 0,0,0 };
	cout << "Enter invoice number for your purchase: ";
	cin >> obj.invoice;
	while (obj.invoice < 1000 || obj.invoice> 8000)
	{
		cout << "ERROR! invlid input!\n";
		cout << "Re-enter the invoice number in range of 1000-8000: ";
		cin >> obj.invoice;
	}
	cout << "Enter the amount of purchase: ";
	cin >> obj.amount;
	while (obj.amount < 0)
	{
		cout << "ERROR! invalid input!\n";
		cout << "Your amount should not less than 0!\n";
		cout << "Re-enter amounnt: ";
		cin >> obj.amount;
	}
	obj.tax = obj.amount * 0.16;
	cout << "\nOUTPUT\n";
	cout << "Invoice number: " << obj.invoice << endl;
	cout << fixed << showpoint << setprecision(2);
	cout << "Sales amount (excluding sales tax): " << obj.amount << endl;
	cout << "Sales tax amount: " << obj.tax << endl;
	cout << "Total Sales amount including Tax  (purchase + tax): " << obj.amount + obj.tax << endl;

	return 0;
}