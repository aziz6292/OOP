#include <iostream>
#include <string>
#include <iomanip>
using namespace std;

struct Succer
{
	string name = " ";
	int number = 0;
	int point = 0;
};


int main()
{
	const int N = 12;
	Succer player[N];
	int i = 0;
	int totalPoints = 0, largest, index;
	cout << "\tGetting Input Detail for " << N << " Players!\n\n";
	while (i < N)
	{
		cout << "Enter Player " << i + 1 << " name: ";
		getline(cin, player[i].name);
		cout << "Enter " << player[i].name << " number: ";
		cin >> player[i].number;
		cout << "Enter Points score by " << player[i].name << ": ";
		cin >> player[i].point;
		if (i == 0)
		{
			largest = player[i].point;
			index = i;
		}
		else
		{
			if (player[i].point > largest)
			{
				largest = player[i].point;
				index = i;
			}
		}
		totalPoints += player[i].point;
		i++;
		cout << endl << endl;
		cin.ignore();
	}


	cout << "\nOUTPUT\n\n";
	i = 0;
	cout << fixed << left;
	cout << setw(15) << "Player Number" << setw(20) << "Player Name" << setw(5) << "Player Points\n\n";
	while (i < N)
	{
		cout << setw(15) << player[i].number << setw(20) << player[i].name << setw(5) << player[i].point << endl;
		i++;
	}
	cout << endl;
	cout << "Total team points: " << totalPoints << endl;
	cout << "Player with maximum Points!\n\n";
	cout << setw(15) << player[index].number << setw(20) << player[index].name << setw(5) << player[index].point << endl;

	system("pause>0");
	return 0;
}