#include <iostream>
using namespace std;



struct Apartment
{
	short int bedrooms;
	short int baths;
	int rent;
};


int main()
{
	Apartment  apartment1 = { 0,0,0 };
	cout << "Enter no of badrooms and baths: ";
	cin >> apartment1.bedrooms >> apartment1.baths;
	while (apartment1.bedrooms < 1 || apartment1.bedrooms>3)
	{
		cout << "ERROR! invalid input!\n";
		cout << "badrooms should be in range of 1-3: ";
		cin >> apartment1.bedrooms;
	}
	while (apartment1.baths < 1 || apartment1.baths>2)
	{
		cout << "ERROR! invalid input!\n";
		cout << "baths should be in range of 1-2: ";
		cin >> apartment1.baths;
	}
	if (apartment1.bedrooms == 1)
	{
		if (apartment1.baths == 1)
			apartment1.rent = 8000;
		else
			apartment1.rent = 0;
	}
	else if (apartment1.bedrooms == 2)
	{
		if (apartment1.baths == 1)
			apartment1.rent = 14000;
		else
			apartment1.rent = 16000;
	}
	else
	{
		if (apartment1.baths == 1)
			apartment1.rent = 0;
		else
			apartment1.rent = 18500;
	}
	cout << "\nOUTPUTS\n";
	cout << "No of badrooms: " << apartment1.bedrooms << endl;
	cout << "No of baths: " << apartment1.baths << endl;
	if (apartment1.rent != 0)
		cout << "Rent for Desires apartment is: Rs. " << apartment1.rent << endl;
	else
	{
		cout << "Oops! Your Desires apartment is Not availble!\n";
	}
	return 0;
}