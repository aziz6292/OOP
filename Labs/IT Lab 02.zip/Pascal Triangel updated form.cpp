#include <iostream>
#include <iomanip>
using namespace std;

//Functions Prototypes as given in the LAB
int** createPascalTriangle(int);
void displayPascalTriangle(int**, int);
void deallocatePascalTriangle(int**&, int); // we pass the 2D pointer by reference to deallocate exectly

int main()
{
	int n;
	//geting # of rows
	cout << "# of rows for Pascal Triangle> ";
	cin >> n;
	//input validation
	while (n <= 0)
	{
		cout << "Oops! Row should be at least 1:)";
		cout << "Re-enter the no of rows> ";
		cin >> n;
	}
	// Function Calling 
	// Creating Pascal Triangle
	cout << "Creating && Displaying Pascal Triangle having Rows " << n << endl << endl;
	int** raggedArray2D = createPascalTriangle(n);
	//Displaying the Pascal Triangle
	displayPascalTriangle(raggedArray2D, n);
	//Deleting the Pascal Triangle
	deallocatePascalTriangle(raggedArray2D, n);
	cout << "\npress any key......";
	system("pause>0");
	return 0;
}
int** createPascalTriangle(int n)
{
	//Creating 2D Dynomically Arrays of n # of rows
	int** pt = new int* [n];
	int j = 1, i = 0;
	//Now Creating each Rows pointer carring increasing orders of columns
	while (i < n)
	{
		pt[i] = new int[j];
		j++;
		i++;
	}
	i = 0;
	// Creating the Pascal Triangles
	while (i < n)
	{
		j = 1;
		pt[i][0] = 1; // to assign 1 to all index of 2D Arrays for column 0 mean 1st column

		while (j < i)
		{
			//  for the abave left index  (row = i-1)(col = j-1)
			// and for the perfect above index (row = i-1)( col = j)
			// current element index  is (i)(j)
			pt[i][j] = pt[i - 1][j - 1] + pt[i - 1][j];
			j++;
		}
		// to assign 1 to all last element of  each rows of the 2D Arrays
		pt[i][i] = 1;
		i++;
	}
	return pt;
}
void displayPascalTriangle(int** pt, int n)
{
	int i = 0;
	int j;
	//Displaying Simple 2D in ragged Tringle formate
	while (i < n)
	{
		j = 0;
		cout << fixed << left;
		while (j < i + 1)
		{
			cout << setw(2) << pt[i][j] << " ";
			j++;
		}cout << endl;
		i++;
	}

}
void deallocatePascalTriangle(int**& pt, int n)
{
	int i = 0;
	while (i < n)
	{
		//Deallocating each Row pointer
		delete[]pt[i];
		//Avaiding Dangling pointer issue
		pt[i] = nullptr;
		i = i + 1;
	}
	// Deallocating/Avaiding Dangling problem  of 2D arrays of pointers for Rows
	delete[]pt;
	pt = nullptr;
}
