//  Name          Roll No
//  Fatima Ansari BCSF20A046
//  Maryam Ali    BCSF20A025
//  Zarnab        BCSF20A016
#include "RoadMap.h"
RoadMap::RoadMap() : R(1), C(1), F(1), N(1), B(1), T(1), score(0)
{
}
void RoadMap::validate(unsigned long long int &val, int r1, unsigned long long int r2)
{
    while (val < r1 || val > r2)
    {
        cout << "ERROR!! Invalid input\nRe-enter in range of (" << r1 << "-" << r2 << "): ";
        cin >> val;
    }
}
void RoadMap::storeInputToFile()
{
    fout.open("InputData.txt");
    if (!fout)
    {
        cout << "ERROR!\nFile not Created Successfully!\n";
        exit(0);
    }
    else
    {
        unsigned long long int R, C, F, N, B, T, temp;
        cout << "Enter number of row of the gird (1 <= R <= 10000): ";
        cin >> R;
        validate(R, 1, 10000);
        fout << R << " ";
        cout << "Enter number of columns of the gird (1 <= C <= 10000): ";
        cin >> C;
        validate(C, 1, 10000);
        fout << C << " ";
        cout << "Enter number of vehicles in the fleet (1 <= F <= 1000): ";
        cin >> F;
        validate(F, 1, 1000);
        fout << F << " ";
        cout << "Enter number of rides (1 <= N <= 10000): ";
        cin >> N;
        validate(N, 1, 10000);
        fout << N << " ";
        cout << "Enter Pre-ride bonus for starting the ride on time (1 <= B <= 10000): ";
        cin >> B;
        validate(B, 1, 10000);
        fout << B << " ";
        cout << "Enter number of steps in the simulation (1 <= T <= 10^9): ";
        cin >> T;
        validate(T, 1, pow(10, 9));
        fout << T << "\n";
        cout << "The first line of the output file has been successfully stored to the file\n";
        // Now going to the next Step
        // Taking input for each rides
        cout << "\nNow to take more info about each ride\n\n";
        for (int i = 0; i < N; i++)
        {
            // Getting input for ride i
            cout << "\tRide #" << i << " information\n";
            cout << "Enter row of the start intersection (0 <= a < " << R << "): ";
            cin >> temp;
            validate(temp, 0, R);
            fout << temp << " ";
            cout << "Enter column of the start intersection (0 <= b <" << C << "): ";
            cin >> temp;
            validate(temp, 0, C);
            fout << temp << " ";
            cout << "Enter row of the finish intersection (0 <= x < " << R << "): ";
            cin >> temp;
            validate(temp, 0, R);
            fout << temp << " ";
            cout << "Enter column of the finish intersection (0 <= y < " << C << "): ";
            cin >> temp;
            validate(temp, 0, C);
            fout << temp << " ";
            cout << "Enter the earliest start (0 <= s < " << T << "): ";
            cin >> temp;
            validate(temp, 0, T);
            fout << temp << " ";
            cout << "Enter the latest finish (0 <= f <= " << T << "): ";
            cin >> temp;
            validate(temp, 0, T);
            fout << temp << "\n";
            cout << "\n\n";
        }
        fout.close();
    }
}
void RoadMap::simulationToGenerateOutputFile()
{
    fin.open("InputData.txt");
    if (!fin)
    {
        cout << "ERROR!!\n";
        cout << "The input File is not found\n";
        exit(0);
    }
    else
    {
        // "\nNow, As we Know that we already stored the valid data to the file\n";
        // "so, no need of validation from getting data back from the file!\n";
        fin >> R >> C >> F >> N >> B >> T;
        // Now to assign rides to the vehicles
        int vehicle = 0;
        int rides = 0;
        int simulation = 0;
        int a, b, x, y, s, f;
        fout.open("OutputData.txt");
        if (!fout)
        {
            cout << "Output File not Created Successfully\n";
            exit(0);
        }
        else
        {
            bool finalStep = false;    // to check for final step simulation
            int previousRides = rides; // to store the previous rides
            rides = (N - previousRides) / (F - vehicle);
            while (rides <= N && !finalStep)
            {
                fout << rides - previousRides << " "; // No of rides to each vehicle
                int i = 0, j = 0;                     // current position of each vehicle
                int k = rides - 1;
                while (k >= previousRides && !finalStep)
                {
                    simulation = 0;
                    fin >> a >> b >> x >> y >> s >> f;
                    if (i == a && j == b) // check for bonus
                        score += B;       // to increase the total score by bonus B
                    // Now to go to the
                    for (; i < a; i++, simulation++)
                        ;
                    for (; i > a; i--, simulation++)
                        ;
                    for (; j < b; j++, simulation++)
                        ;
                    for (; j > b; j--, simulation++)
                        ;
                    // Now to handle the earliest start
                    for (; simulation < s; simulation++)
                        ;
                    // Now the vehicle is on the starting position
                    // so, it for destination
                    for (; i < x; i++, simulation++)
                        ;
                    for (; i > x; i--, simulation++)
                        ;
                    for (; j < y; j++, simulation++)
                        ;
                    for (; j > y; j--, simulation++)
                        ;
                    // now to check for score and latest finish
                    if (simulation < f)
                        score += abs(x - a) + abs(y - b);
                    else if (simulation >= T)
                        finalStep = true;
                    fout << k << " ";
                    k--;
                }
                fout << endl;
                previousRides = rides; // to store the previous rides
                vehicle++;
                if (N - previousRides)
                    if ((N - previousRides) / (F - vehicle))
                    {
                        rides += (N - previousRides) / (F - vehicle);
                        if ((N - previousRides) % (F - vehicle))
                            rides++;
                    }
                    else
                        rides += N - previousRides;
                else
                    rides++;
            }
            fout.close();
        }
        fin.close();
    }
}
const int RoadMap::getScore()
{
    return score;
}