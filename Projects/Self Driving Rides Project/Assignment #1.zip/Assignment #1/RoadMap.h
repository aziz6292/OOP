//  Name          Roll No
//  Fatima Ansari BCSF20A046
//  Maryam Ali    BCSF20A025
//  Zarnab        BCSF20A016
#pragma once
#include <iostream>
#include <fstream>
#include <cmath>
using namespace std;
class RoadMap
{
private:
    int R, C, F, N, B, T, score;
    ofstream fout;
    ifstream fin;
    void validate(unsigned long long int &, int, unsigned long long int);

public:
    RoadMap();
    void storeInputToFile();
    void simulationToGenerateOutputFile();
    const int getScore();
};
