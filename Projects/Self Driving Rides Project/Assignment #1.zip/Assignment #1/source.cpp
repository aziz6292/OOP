//  Name          Roll No
//  Fatima Ansari BCSF20A046
//  Maryam Ali    BCSF20A025
//  Zarnab        BCSF20A016

#include "RoadMap.cpp"
int main()
{
    RoadMap simulation{};
    simulation.storeInputToFile();
    simulation.simulationToGenerateOutputFile();
    cout << "\nTotal Score of all rides: " << simulation.getScore() << endl  << endl;
    return 0;
}
