#include "LectureRoom.h"
LectureRoom::LectureRoom(const char* n, int no, int c)
{
	cout << "LecRoom Parametrize Constructor on " << this << endl;
	setData(n, no, c);
}
LectureRoom::LectureRoom(LectureRoom& obj)
{
	cout << "LecRoom Copy Constructor on " << this << endl;
	setData(obj.getName(), obj.getNo(), obj.getCapacity());
}
void LectureRoom::setData(const char* n, int no, int c)
{
	if (roomName != NULL)
	{
		delete roomName;
		roomName = NULL;
	}
	if (n != NULL)
	{
		roomName = new char[strlen(n) + 1];
		strcpy(roomName, n);
	}
	if (no > 0)
	{
		roomNo = no;
	}
	else
	{
		roomNo = 0;
	}
	if (c > 0)
	{
		capacity = c;
	}
	else
	{
		capacity = 0;
	}
}
const char* LectureRoom::getName()const
{
	return roomName;
}
const int LectureRoom::getNo()const
{
	return roomNo;
}
const int LectureRoom::getCapacity()const
{
	return capacity;
}
void LectureRoom::display()const
{
	cout <<  getName() << "\t";
	cout <<  getNo() << "\t";
	cout <<  getCapacity()<<" Capacity" << endl;

}
LectureRoom ::~LectureRoom()
{
	cout << "LecRoom Destructor Call on " << this << endl;
	if (roomName != NULL)
	{
		delete [] roomName;
		roomName = NULL;
	}
}