#include "Building.h"

int main()
{
	int noLab, noLecRooms;
	cout << "Enter no of Labs: ";
	cin >> noLab;
	cout << "Enter no of Lecture Rooms: ";
	cin >> noLecRooms;
	const int  S = 20;
	char bName[S];
	Lab* labs = new Lab[noLab];
	LectureRoom* lectureRooms = new LectureRoom[noLecRooms];
	cout << "Enter Name of Building\n";
	cin.ignore();
	cin.getline(bName, S);
	int a = 0;
	labs[0].display();
	if (a < 1)
	{
		Building  B = { bName,labs, lectureRooms , noLab , noLecRooms };
		B.display();
		for (int i = 0; i < noLab; i++)
			B.insertLab();
		for (int i = 0; i < noLecRooms; i++)
			B.insertLecRoom();
		B.display();
		B.deleteLab();
		B.deleteLecRoom();
		B.display();
	}
	//Now if the below fun we call for labs[0] it will run time error
	// due to deletion in Buiding distructor for B object
	//labs[0].display();
	return 0;
}