#pragma once
#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <string>
using namespace std;
class LectureRoom
{
	char* roomName;
	int roomNo;
	int capacity;
public:
	LectureRoom() : roomNo(0), capacity(0)
	{
		roomName = new char[1];
		strcpy(roomName, "");
		cout << "Lecture Room Default Constructer Call on " << this << endl;
	}
	LectureRoom(const char*, int, int);
	LectureRoom(LectureRoom&);
	void setData(const char*, int, int);
	const char* getName()const;
	const int getNo()const;
	const int getCapacity()const;
	void display()const;
	~LectureRoom();
};

