#pragma once
#include"Lab.h"
#include "LectureRoom.h"
class Building
{
	char* name;
	Lab* lab;
	LectureRoom* lecRoom;
	int noRooms, noLabs;

public:
	Building(const char* , Lab*, LectureRoom*, int = 0, int = 0);
	void showAllLabs()const;
	void showAllLectureRooms()const;
	void insertLab();
	void insertLecRoom();
	void deleteLab();
	void deleteLecRoom();
	void setData(const char*, int, int);
	void display()const;
	Building(const Building&);
	~Building();
};

