#include "Lab.h"
Lab::Lab(const char* n, int c) 
{
	cout << "Lab Permetrize Constructor Call on " << this << endl;
	setData(n, c);
}
Lab::Lab(const Lab& obj)
{
	cout << "Lab CC Call on " << this << endl;
	setData(obj.getName(), obj.getCapacity());
}
void Lab::setData(const char* n, int c)
{
	if (labName != NULL)
	{
		delete labName;
		labName = NULL;
	}
	if (n != NULL)
	{
		labName = new char[strlen(n) + 1];
		strcpy(labName, n);
	}
	if (c > 0)
	{
		capacity = c;
	}
	else
	{
		capacity = 0;
	}

}
const char* Lab::getName()const
{
	return labName;
}
const int Lab :: getCapacity()const
{
	return capacity;
}
void Lab::display()const
{
	cout << "Lab " << getName() << "\t";
	cout  <<getCapacity() <<" Capacity" << endl;
}
Lab ::~Lab()
{
	cout << "Lab Destructor Call on " << this << endl;
	if (labName != NULL)
	{
		delete [] labName;
		labName = NULL;
	}
}