#pragma once
#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <string>
using namespace std;
class Lab
{
	char* labName;
	int capacity;
public:
	Lab() :capacity(0)
	{
		labName = new char[1];
		strcpy(labName, "");
		cout << "Lab Default Constructer Call on " << this << endl;
	}
	Lab(const char*, int);
	Lab(const Lab&);
	void setData(const char*, int);
	const char* getName()const;
	const int getCapacity()const;
	void display()const;
	~Lab();
};

