#include "Building.h"
#define S 20
Building::Building(const char* name, Lab* l, LectureRoom* r, int noL, int noR) :lab(l), lecRoom(r)
{
	setData(name, noL, noR);
	cout << "Building Constructor Call on " << this << endl;
}
void Building::showAllLabs()const
{
	cout << "Show all labs:\n";
	for (int i = 0; i < noLabs; i++)
		lab->display();
}
void Building::showAllLectureRooms()const
{
	cout << "\nShow all lectures room:\n";
	for (int i = 0; i < noRooms; i++)
		lecRoom->display();
}
void Building::insertLab()
{
	char n[S];
	int c, i;
	cout << "Enter the Location/index (int) to insert lab at: ";
	cin >> i;
	while (i < 0 || i>= noLabs)
	{
		cout << "Invalid\n";
		cout << "Re-enter in range of 0_" << noLabs-1 << ": ";
		cin >> i;
	}
	cout << "Enter Lab name: ";
	cin.ignore();
	cin.getline(n, S);
	cout << "Enter " << n << " Capacity: ";
	cin >> c;
	lab[i].setData(n, c);
}
void Building::insertLecRoom()
{

	char n[S];
	int c, i, no;
	cout << "Enter the Location/index (int) to insert lecture Room at: ";
	cin >> i;
	while (i < 0 || i>= noRooms)
	{
		cout << "Invalid\n";
		cout << "Re-enter in range of 0_" << noRooms-1 << ": ";
		cin >> i;
	}
	cout << "Enter Lecture Room Name: ";
	cin.ignore();
	cin.getline(n, S);
	cout << "Enter " << n << " No #";
	cin >> no;
	cout << "Enter " << n << " Capacity: ";
	cin >> c;
	lecRoom[i].setData(n, no, c);
}
void Building::deleteLab()
{
	int i;
	cout << "Enter the Lab no to Delete: ";
	cin >> i;
	lab[i].setData("",0);
}
void Building::deleteLecRoom()
{
	int i;
	cout << "Enter the Lecture Room no to Delete: ";
	cin >> i;
	lecRoom[i].setData("", 0, 0);
}
void Building :: setData(const char* n, int noL, int noR)
{
	if (name != NULL)
	{
		delete name;
		name = NULL;
	}
	if (n != NULL)
	{
		name = new char[strlen(n) + 1];
		strcpy(name, n);
	}
	if (noL > 0)
	{
		noLabs = noL;
	}
	else
	{
		noLabs = 1;
	}
	if (noR > 0)
	{
		noRooms = noR;
	}
	else
	{
		noRooms= 1;
	}
}
void Building :: display()const
{
	cout << "Welcome To " << name << " Building\n\n";
	showAllLabs();
	showAllLectureRooms();

}
Building::Building(const Building& obj): lab(obj.lab), lecRoom(obj.lecRoom)
{
	cout << "Building Copy Constructor Call on " << this << endl;
	setData(obj.name, obj.noLabs, obj.noRooms);
}
Building :: ~Building()
{
	lab->~Lab();
	lecRoom->~LectureRoom();
	cout << "Buliding Destructor Call on " << this << endl;
	if (name != NULL)
	{
		delete [] name;
		name = NULL;
	}
}