#pragma once
#include"Address.h"
class Student
{
	string name;
	int rollNo;
	string email;
	Address* ptrAddress;
public:
	Student(string = "", int = 0, string = "" );
	void setData(string = "", int = 0, string = "" );
	string getName()const;
	int getRollNo()const;
	void setAddressAtIndex( Address*);
	string getEmail()const;
	void display()const;
	~Student()
	{
		cout << "Student distructor call on " << this << endl;
	}
};

