#pragma once
#include <iostream>
#include <cstring>
#include <iomanip>
#include <string>
#include <cctype>
using namespace std;
class Address
{
	string city, state, country;
	int zipCode;
public:
	Address(string = "", string = "", string = "", int = 0);
	void setData(string = "", string = "", string = "", int = 0);
	string getCity()const;
	string getState()const;
	string getCountry()const;
	int getZipCode()const;
	string getAddress()const;
	void display()const;
	~Address()
	{
		cout << "Address Distructor call on " << this << endl;
	}
};

