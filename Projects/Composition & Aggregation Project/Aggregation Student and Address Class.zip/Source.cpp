#include"Student.h"
int main()
{
	Address a = { "Lahore", "N/A","Pakistan",18700 };
	a.display();
	cout << endl;
	if (1)
	{
		int no;
		cout << "Enter the no of Student: ";
		cin >> no;
		Student* std = new Student[no];
		string name, email;
		int roll;
		for (int i = 0; i < no; i++)
		{
			cout << "Enter name: ";
			cin.ignore();
			getline(cin, name);
			cout << "Enter Email: ";
			getline(cin, email);
			cout << "Enter roll No: ";
			cin >> roll;
			std[i].setData(name, roll, email);
			std[i].setAddressAtIndex( &a);
		
		}
		for (int i = 0; i < no; i++)
			std[i].display();
		delete[] std;
		std = NULL;
	}

	cout << "\n\nSince Aggregation so the scope is already over but still\n we can access the a object of address"<<endl;
	a.display();
	return 0;
}