#include "Student.h"
Student::Student(string n, int r, string em)
{
	cout << "Student constructor call on " << this << endl;
	setData(n, r, em);
}
void Student::setData(string n, int r, string em)
{
	if (!n.empty())
		name = n;
	else
		name = "";
	if (!em.empty())
		email = em;
	else
		email = "";
	if (r > 0)
		rollNo = r;
	else
		rollNo = 0;
	//ptrAddress[0]->setData(add.getCity(), add.getState(), add.getCountry(), add.getZipCode());
}
void Student::setAddressAtIndex( Address * add)
{
		ptrAddress = add;
}
string Student::getName()const
{
	return name;
}
int Student::getRollNo()const
{
	return rollNo;
}
string Student::getEmail()const
{
	return email;
}
void Student::display()const
{
	cout << fixed << left;
	cout << setw(20) << getName() << setw(10) << getRollNo();
	cout << setw(30) << getEmail() << setw(50);
	ptrAddress->display();
}