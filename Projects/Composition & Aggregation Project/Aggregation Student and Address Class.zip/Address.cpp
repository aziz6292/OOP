#include "Address.h"
#include <string>
Address::Address(string cit, string st, string cont, int zip)
{
	cout << "Address Constructor call on " << this << endl;
	setData(cit, st, cont, zip);
}
void Address::setData(string cit, string st, string cont, int zip)
{
	if (!cit.empty())
		city = cit;
	else
		city = "";
	if (!st.empty())
		state = st;
	else
		state = "";
	if (!cont.empty())
		country = cont;
	else
		country = "";
	if (zip > 0)
		zipCode = zip;
	else
		zipCode = 0;

}
string Address::getCity()const
{
	return city;
}
string Address::getState()const
{
	return state;
}
string Address::getCountry()const
{
	return country;
}
int Address::getZipCode()const
{
	return zipCode;
}
string Address::getAddress()const
{
	string address = getCity();
	int s = getCity().size();
	address.insert(s, ",");
	s++;
	address.insert(s , getState());
	s = s + getState().size();
	address.insert(s, ",");
	s++;
	address.insert(s, getCountry());
	s = s + getCountry().size();
	address.insert(s, ",(");
	s++;
	s++;
	address.insert(s, to_string(getZipCode()));
	s = s + to_string(getZipCode()).size();
	address.insert(s, ")");
	return address;
}
void Address::display()const
{
	cout << getAddress() << endl;
}